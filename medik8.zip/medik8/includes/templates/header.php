<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Medik8 | Productos</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Questrial" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500" rel="stylesheet"> 
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    
    <header>
        <div class="container cabecera">
            <div class="row">
                <div class="col-sm-4 col-md-4">
                    <ul class="nav menu-colores justify-content-start">

                        <li class="nav-item">
                            <a href="http://digitalscrab.com/medik8/product-category/antiage/" class="nav-link boton boton1"><div></div>
                                <div class="muestra">Blemish</div>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="http://digitalscrab.com/medik8/product-category/pigmentacion/" class="boton nav-link boton2"><div></div>
                                <div class="muestra">Recovery</div>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="http://digitalscrab.com/medik8/product-category/rojeces/" class="nav-link boton boton3"><div></div>
                                <div class="muestra">Pigmentacion</div>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="http://digitalscrab.com/medik8/product-category/antiage/" class="nav-link boton boton4"><div></div>
                                <div class="muestra">Pore Refining</div>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="http://digitalscrab.com/medik8/product-category/antiage/" class="nav-link boton boton5"><div></div>
                                <div class="muestra">Redness</div>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="http://digitalscrab.com/medik8/product-category/antiage/" class="nav-link boton boton6"><div></div>
                                <div class="muestra">Skin Aging</div>
                            </a>
                        </li>

                    </ul>

                </div>

                <div class="col-sm-4 col-md-4">
                <a href="index.php">
                    <img src="img/logo.png" alt="" class="img-fluid">
                    </a>
                </div>

                <div class="col-sm-4 col-md-4">
                    <ul class="justify-content-end nav compras-menu">
                        <li class="nav-item">
                            <a href="" class="nav-link"><i class="fas fa-search"></i></a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link"><i class="fas fa-user-circle"></i></a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link"><i class="far fa-heart"></i></a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link"><i class="fas fa-shopping-bag"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-12 mt-4">
                    <nav class="navbar navbar-expand-lg nabvar-light">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menu-principal" aria-controls="menu-principal" aria-expanded="false">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse menu-principal" id="menu-principal">
                            <ul class="navbar-nav nav-fill mx-auto w-100 justify-content-center">
                                <li class="nav-item">
                                    <a href="#" class="nav-link">*Descubra*</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">Productos</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">La piel explicada</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">Tratamientos Profesionales</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">Sobre Medik8</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">r-Retionate ®</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
        </div>
    </header>

    <!-- FIN MENU Y HEAD  -->