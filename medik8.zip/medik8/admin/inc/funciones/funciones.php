<?php 

require_once('../includes/funciones/conexion.php');