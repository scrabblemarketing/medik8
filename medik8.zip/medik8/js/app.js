$('.carousel').carousel({
    interval: false
})

var owl = $('.owl-carousel');
owl.owlCarousel({
    margin: 10,
    loop: true,
    responsive: {
        0: {
            items: 2
        },
        600: {
            items: 3
        },
        1000: {
            items: 4
        },
    },
    mouseDrag: true,
    autoplay: false,
    URLhashListener: true
});



$('.menu-caracteristicas li a').on('click', function(e) {
    e.preventDefault();
    $('.menu-caracteristicas li a').removeClass('active');

    $(this).addClass('active');
    const link = $(this).attr('href');
    $('.box-descripcion').removeClass('active');

    $('.box-descripcion' + link).addClass('active')
})